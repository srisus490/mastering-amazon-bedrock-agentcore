/**
 * UI Manager Module
 * Handles DOM manipulation and user interaction
 */

export class UIManager {
    constructor(stateManager, apiClient) {
        this.stateManager = stateManager;
        this.apiClient = apiClient;
        this.currentPage = 1;
        this.pageSize = 50;
        console.log('UIManager initialized');
    }

    /**
     * Initialize UI and setup event listeners
     */
    initialize() {
        this.setupEventListeners();
    }

    /**
     * Setup event listeners for user interactions
     */
    setupEventListeners() {
        // System selection dropdown
        const systemSelect = document.getElementById('system-select');
        if (systemSelect) {
            systemSelect.addEventListener('change', (e) => {
                this.stateManager.setSelectedSystem(e.target.value || null);
            });
        }

        // Date range filters
        const startDateInput = document.getElementById('start-date');
        const endDateInput = document.getElementById('end-date');
        if (startDateInput && endDateInput) {
            startDateInput.addEventListener('change', () => {
                this.handleDateRangeChange();
            });
            endDateInput.addEventListener('change', () => {
                this.handleDateRangeChange();
            });
        }

        // Clear filters button
        const clearFiltersBtn = document.getElementById('clear-filters');
        if (clearFiltersBtn) {
            clearFiltersBtn.addEventListener('click', () => {
                this.clearFilters();
            });
        }

        // Manual refresh button
        const refreshBtn = document.getElementById('manual-refresh');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => {
                this.stateManager.notify('manualRefresh');
            });
        }

        // Tab buttons
        const tabButtons = document.querySelectorAll('.tab-btn');
        tabButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const tabId = e.target.dataset.tab;
                this.switchTab(tabId);
            });
        });
    }

    /**
     * Switch between tabs in the details section
     * @param {string} tabId - The tab to switch to
     */
    switchTab(tabId) {
        // Update tab buttons
        document.querySelectorAll('.tab-btn').forEach(btn => {
            if (btn.dataset.tab === tabId) {
                btn.classList.add('active');
                btn.setAttribute('aria-selected', 'true');
            } else {
                btn.classList.remove('active');
                btn.setAttribute('aria-selected', 'false');
            }
        });

        // Update tab content
        document.querySelectorAll('.tab-content').forEach(content => {
            if (content.id === tabId) {
                content.classList.add('active');
            } else {
                content.classList.remove('active');
            }
        });
    }

    /**
     * Handle date range changes with validation
     */
    handleDateRangeChange() {
        const startDateInput = document.getElementById('start-date');
        const endDateInput = document.getElementById('end-date');
        
        console.log('handleDateRangeChange called');
        console.log('Start date input:', startDateInput?.value);
        console.log('End date input:', endDateInput?.value);
        
        if (!startDateInput || !endDateInput) return;

        const startDate = startDateInput.value ? new Date(startDateInput.value) : null;
        const endDate = endDateInput.value ? new Date(endDateInput.value) : null;

        console.log('Parsed dates - start:', startDate, 'end:', endDate);

        // Validate date range
        if (startDate && endDate && startDate > endDate) {
            this.renderErrorMessage('Start date must be before end date', 'date-range-error');
            return;
        }

        // Clear any previous error
        const errorContainer = document.getElementById('date-range-error');
        if (errorContainer) {
            errorContainer.innerHTML = '';
        }

        console.log('Calling stateManager.setDateRange');
        this.stateManager.setDateRange(startDate, endDate);
    }

    /**
     * Clear all filters
     */
    clearFilters() {
        // Reset system selection
        const systemSelect = document.getElementById('system-select');
        if (systemSelect) {
            systemSelect.value = '';
        }

        // Reset date inputs
        const startDateInput = document.getElementById('start-date');
        const endDateInput = document.getElementById('end-date');
        if (startDateInput) startDateInput.value = '';
        if (endDateInput) endDateInput.value = '';

        // Clear state
        this.stateManager.setSelectedSystem(null);
        this.stateManager.setDateRange(null, null);
        this.stateManager.setFilters({});

        // Clear any errors
        const errorContainer = document.getElementById('date-range-error');
        if (errorContainer) {
            errorContainer.innerHTML = '';
        }
    }

    /**
     * Render system overview cards
     * @param {Array} systems - Array of system summary objects
     */
    renderSystemOverview(systems) {
        const container = document.getElementById('system-overview');
        if (!container) return;

        if (!systems || systems.length === 0) {
            container.innerHTML = '<p class="no-data">No systems found</p>';
            return;
        }

        // Filter systems if a specific system is selected
        const selectedSystem = this.stateManager.getSelectedSystem();
        let displaySystems = systems;
        if (selectedSystem) {
            displaySystems = systems.filter(s => 
                (s.source_system_id || s.sourceSystemId) === selectedSystem
            );
        }

        // Check if we have date range data
        const hasDateRange = displaySystems.some(s => s.file_count_range !== null && s.file_count_range !== undefined);
        console.log('renderSystemOverview - hasDateRange:', hasDateRange);
        console.log('renderSystemOverview - sample system:', displaySystems[0]);

        container.innerHTML = displaySystems.map(system => {
            // Handle both camelCase and snake_case field names from API
            const systemId = system.source_system_id || system.sourceSystemId;
            const fileCountToday = system.file_count_today !== undefined ? system.file_count_today : system.file_count;
            const fileCountRange = system.file_count_range;
            const lastArrival = system.last_arrival || system.lastFileArrival;
            const slaScore = system.sla_score !== undefined ? system.sla_score : system.slaScore;
            const status = system.status || 'healthy';
            const hasViolations = system.hasViolations || (slaScore !== undefined && slaScore < 80);
            
            const statusClass = this.getStatusClass(status);
            const warningClass = hasViolations ? 'has-warning' : '';
            
            console.log(`System ${systemId}: fileCountToday=${fileCountToday}, fileCountRange=${fileCountRange}, hasDateRange=${hasDateRange}`);
            
            return `
                <div class="system-card ${statusClass} ${warningClass}" data-system-id="${systemId}">
                    <div class="system-header">
                        <h3 class="system-name">${this.escapeHtml(systemId)}</h3>
                        ${hasViolations ? '<span class="warning-indicator">⚠️</span>' : ''}
                    </div>
                    <div class="system-status">
                        <span class="status-badge ${statusClass}">${status}</span>
                    </div>
                    <div class="system-stats">
                        <div class="stat">
                            <span class="stat-label">File Count (Today):</span>
                            <span class="stat-value">${this.formatNumber(fileCountToday || 0)}</span>
                        </div>
                        ${hasDateRange && fileCountRange !== null ? `
                            <div class="stat">
                                <span class="stat-label">Total File Count:</span>
                                <span class="stat-value">${this.formatNumber(fileCountRange)}</span>
                            </div>
                        ` : ''}
                        <div class="stat">
                            <span class="stat-label">SLA Score:</span>
                            <span class="stat-value">${slaScore !== undefined ? slaScore.toFixed(1) : 'N/A'}</span>
                        </div>
                        ${lastArrival ? `
                            <div class="stat">
                                <span class="stat-label">Last Arrival:</span>
                                <span class="stat-value">${this.formatDate(lastArrival)}</span>
                            </div>
                        ` : ''}
                    </div>
                </div>
            `;
        }).join('');

        // Add click handlers to system cards
        container.querySelectorAll('.system-card').forEach(card => {
            card.addEventListener('click', () => {
                const systemId = card.dataset.systemId;
                this.stateManager.setSelectedSystem(systemId);
                
                // Update the dropdown to reflect the selection
                const systemSelect = document.getElementById('system-select');
                if (systemSelect) {
                    systemSelect.value = systemId;
                }
            });
        });

        // Populate the system dropdown
        this.populateSystemDropdown(systems);
    }

    /**
     * Populate system dropdown with available systems
     * @param {Array} systems - Array of system objects
     */
    populateSystemDropdown(systems) {
        const dropdown = document.getElementById('system-select');
        if (!dropdown) return;

        // Keep the "All Systems" option
        const currentValue = dropdown.value;
        dropdown.innerHTML = '<option value="">All Systems</option>';

        // Add each system as an option
        systems.forEach(system => {
            const systemId = system.source_system_id || system.sourceSystemId;
            const option = document.createElement('option');
            option.value = systemId;
            option.textContent = systemId;
            dropdown.appendChild(option);
        });

        // Restore previous selection if it still exists
        if (currentValue) {
            dropdown.value = currentValue;
        }
    }

    /**
     * Render file arrivals with pagination
     * @param {Array} arrivals - Array of file arrival objects
     * @param {number} totalCount - Total number of arrivals
     */
    renderFileArrivals(arrivals, totalCount = null) {
        const container = document.getElementById('file-arrivals');
        if (!container) return;

        if (!arrivals || arrivals.length === 0) {
            container.innerHTML = '<p class="no-data">No file arrivals found</p>';
            return;
        }

        const total = totalCount || arrivals.length;
        const totalPages = Math.ceil(total / this.pageSize);

        let html = `
            <div class="file-arrivals-table">
                <table>
                    <thead>
                        <tr>
                            <th>File Name</th>
                            <th>Arrival Time</th>
                            <th>Source System</th>
                            <th>File Size</th>
                            <th>Checksum</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        arrivals.forEach(arrival => {
            // Handle both camelCase and snake_case field names
            const fileName = arrival.filename || arrival.fileName || 'Unknown';
            const arrivalTime = arrival.arrival_timestamp || arrival.arrivalTime;
            const sourceSystem = arrival.source_system_id || arrival.sourceSystemId || 'Unknown';
            const fileSize = arrival.file_size_bytes !== undefined ? arrival.file_size_bytes : arrival.fileSize;
            const checksum = arrival.checksum || 'N/A';
            
            html += `
                <tr>
                    <td class="file-name" title="${this.escapeHtml(fileName)}">${this.escapeHtml(fileName)}</td>
                    <td>${this.formatDate(arrivalTime)}</td>
                    <td>${this.escapeHtml(sourceSystem)}</td>
                    <td>${this.formatFileSize(fileSize)}</td>
                    <td class="checksum" title="${this.escapeHtml(checksum)}">${checksum ? checksum.substring(0, 8) + '...' : 'N/A'}</td>
                </tr>
            `;
        });

        html += `
                    </tbody>
                </table>
            </div>
        `;

        // Add pagination if needed
        if (total > this.pageSize) {
            html += this.renderPagination(this.currentPage, totalPages, total);
        }

        container.innerHTML = html;

        // Setup pagination event listeners
        this.setupPaginationListeners();
    }

    /**
     * Render pagination controls
     * @param {number} currentPage - Current page number
     * @param {number} totalPages - Total number of pages
     * @param {number} totalItems - Total number of items
     * @returns {string} HTML string for pagination
     */
    renderPagination(currentPage, totalPages, totalItems) {
        const startItem = (currentPage - 1) * this.pageSize + 1;
        const endItem = Math.min(currentPage * this.pageSize, totalItems);

        let html = `
            <div class="pagination">
                <div class="pagination-info">
                    Showing ${startItem}-${endItem} of ${this.formatNumber(totalItems)}
                </div>
                <div class="pagination-controls">
        `;

        // Previous button
        html += `
            <button class="pagination-btn" data-page="${currentPage - 1}" ${currentPage === 1 ? 'disabled' : ''}>
                Previous
            </button>
        `;

        // Page numbers (show max 5 pages)
        const maxPages = 5;
        let startPage = Math.max(1, currentPage - Math.floor(maxPages / 2));
        let endPage = Math.min(totalPages, startPage + maxPages - 1);
        
        if (endPage - startPage < maxPages - 1) {
            startPage = Math.max(1, endPage - maxPages + 1);
        }

        if (startPage > 1) {
            html += `<button class="pagination-btn" data-page="1">1</button>`;
            if (startPage > 2) {
                html += `<span class="pagination-ellipsis">...</span>`;
            }
        }

        for (let i = startPage; i <= endPage; i++) {
            html += `
                <button class="pagination-btn ${i === currentPage ? 'active' : ''}" data-page="${i}">
                    ${i}
                </button>
            `;
        }

        if (endPage < totalPages) {
            if (endPage < totalPages - 1) {
                html += `<span class="pagination-ellipsis">...</span>`;
            }
            html += `<button class="pagination-btn" data-page="${totalPages}">${totalPages}</button>`;
        }

        // Next button
        html += `
            <button class="pagination-btn" data-page="${currentPage + 1}" ${currentPage === totalPages ? 'disabled' : ''}>
                Next
            </button>
        `;

        html += `
                </div>
            </div>
        `;

        return html;
    }

    /**
     * Setup pagination event listeners
     */
    setupPaginationListeners() {
        const paginationBtns = document.querySelectorAll('.pagination-btn');
        paginationBtns.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const page = parseInt(e.target.dataset.page);
                if (page && page !== this.currentPage) {
                    this.currentPage = page;
                    this.stateManager.notify('pageChange', { page });
                }
            });
        });
    }

    /**
     * Render SLA metrics
     * @param {Object} scores - SLA scores object
     * @param {Array} violations - Array of SLA violations
     */
    renderSLAMetrics(scores, violations) {
        const container = document.getElementById('sla-metrics');
        if (!container) return;

        let html = '<div class="sla-metrics-container">';

        // Render SLA scores
        if (scores && scores.average_score !== undefined) {
            const score = scores.average_score;
            const scoreClass = score < 80 ? 'warning' : score >= 95 ? 'healthy' : 'normal';
            const showWarning = score < 80;

            html += `
                <div class="sla-score-card ${scoreClass}">
                    <h3>SLA Score</h3>
                    <div class="score-display">
                        <span class="score-value">${score.toFixed(1)}</span>
                        ${showWarning ? '<span class="warning-indicator">⚠️</span>' : ''}
                    </div>
                    <div class="score-threshold">
                        Warning Threshold: 80
                    </div>
                    <div class="score-status">
                        ${score >= 80 ? '✓ Compliant' : '✗ Non-Compliant'}
                    </div>
                    <div class="score-period">
                        Period: ${scores.start_date || 'N/A'} to ${scores.end_date || 'N/A'}
                    </div>
                </div>
            `;
        } else {
            html += `
                <div class="sla-score-card">
                    <h3>SLA Score</h3>
                    <div class="score-display">
                        <span class="score-value">N/A</span>
                    </div>
                    <p class="no-data">No SLA data available for this system</p>
                </div>
            `;
        }

        // Render violations
        if (violations && violations.length > 0) {
            html += `
                <div class="sla-violations">
                    <h3>SLA Violations (${violations.length})</h3>
                    <div class="violations-list">
            `;

            violations.forEach(violation => {
                const severityColor = this.getSeverityColor(violation.severity);
                const violationType = violation.violation_type || 'Unknown';
                const violationDate = violation.violation_date;
                const expectedValue = violation.expected_value || 'N/A';
                const actualValue = violation.actual_value || 'N/A';
                
                html += `
                    <div class="violation-item" style="border-left-color: ${severityColor}">
                        <div class="violation-header">
                            <span class="violation-severity ${violation.severity}">${violation.severity}</span>
                            <span class="violation-time">${this.formatDate(violationDate)}</span>
                        </div>
                        <div class="violation-type">${this.escapeHtml(violationType)}</div>
                        <div class="violation-details">
                            <div>Expected: ${this.escapeHtml(expectedValue)}</div>
                            <div>Actual: ${this.escapeHtml(actualValue)}</div>
                        </div>
                    </div>
                `;
            });

            html += `
                    </div>
                </div>
            `;
        } else if (scores) {
            html += '<div class="no-violations"><p>✓ No SLA violations</p></div>';
        }

        html += '</div>';
        container.innerHTML = html;
    }

    /**
     * Render filter controls
     */
    renderFilters() {
        const container = document.getElementById('filters');
        if (!container) return;

        // This method can be used to dynamically populate filter options
        // For now, filters are defined in HTML, but this can be extended
        console.log('Filters rendered');
    }

    /**
     * Render error message
     * @param {string|Error} error - Error message or Error object
     * @param {string} containerId - Optional container ID for the error
     */
    renderErrorMessage(error, containerId = 'error-banner') {
        const container = document.getElementById(containerId);
        if (!container) {
            console.error('Error container not found:', containerId);
            return;
        }

        const errorMessage = error instanceof Error ? error.message : error;
        const errorDetails = error instanceof Error && error.stack ? error.stack : '';

        container.innerHTML = `
            <div class="error-message">
                <span class="error-icon">⚠️</span>
                <div class="error-content">
                    <div class="error-title">Error</div>
                    <div class="error-text">${this.escapeHtml(errorMessage)}</div>
                    ${this.getErrorGuidance(errorMessage)}
                </div>
                <button class="error-close" onclick="this.parentElement.remove()">×</button>
            </div>
        `;

        container.style.display = 'block';

        // Log to console for debugging
        console.error('Error:', errorMessage, errorDetails);
    }

    /**
     * Get actionable guidance for common errors
     * @param {string} errorMessage - Error message
     * @returns {string} HTML string with guidance
     */
    getErrorGuidance(errorMessage) {
        const lowerMessage = errorMessage.toLowerCase();
        
        if (lowerMessage.includes('network') || lowerMessage.includes('fetch')) {
            return '<div class="error-guidance">Check if the API is running at http://localhost:8000</div>';
        }
        
        if (lowerMessage.includes('timeout')) {
            return '<div class="error-guidance">The request timed out. Please try again.</div>';
        }
        
        if (lowerMessage.includes('404') || lowerMessage.includes('not found')) {
            return '<div class="error-guidance">The requested resource was not found.</div>';
        }
        
        if (lowerMessage.includes('500') || lowerMessage.includes('server error')) {
            return '<div class="error-guidance">Server error occurred. Please try again later.</div>';
        }
        
        return '<div class="error-guidance">Please try refreshing the page or contact support if the issue persists.</div>';
    }

    /**
     * Render loading state
     * @param {string} component - Component name to show loading state for
     */
    renderLoadingState(component) {
        const container = document.getElementById(component);
        if (!container) return;

        container.innerHTML = `
            <div class="loading-state">
                <div class="spinner"></div>
                <p>Loading...</p>
            </div>
        `;
    }

    /**
     * Update last refresh timestamp display
     * @param {Date} timestamp - Timestamp of last refresh
     */
    updateLastRefreshTime(timestamp) {
        const container = document.getElementById('last-refresh-time');
        if (!container) return;

        container.textContent = `Last updated: ${this.formatDate(timestamp)}`;
    }

    /**
     * Show notification message
     * @param {string} message - Notification message
     * @param {string} type - Notification type (success, info, warning, error)
     */
    showNotification(message, type = 'info') {
        const container = document.getElementById('notifications');
        if (!container) return;

        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <span class="notification-message">${this.escapeHtml(message)}</span>
            <button class="notification-close" onclick="this.parentElement.remove()">×</button>
        `;

        container.appendChild(notification);

        // Auto-remove after 5 seconds
        setTimeout(() => {
            notification.remove();
        }, 5000);
    }

    /**
     * Format number with thousand separators
     * @param {number} num - Number to format
     * @returns {string} Formatted number
     */
    formatNumber(num) {
        if (num === null || num === undefined) return 'N/A';
        return num.toLocaleString('en-US');
    }

    /**
     * Format date to readable string
     * @param {Date|string} date - Date to format
     * @returns {string} Formatted date string
     */
    formatDate(date) {
        if (!date) return 'N/A';
        
        const d = date instanceof Date ? date : new Date(date);
        
        if (isNaN(d.getTime())) return 'Invalid Date';
        
        return d.toLocaleString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    /**
     * Format file size to human-readable string
     * @param {number} bytes - File size in bytes
     * @returns {string} Formatted file size
     */
    formatFileSize(bytes) {
        if (bytes === null || bytes === undefined) return 'N/A';
        if (bytes === 0) return '0 Bytes';

        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));

        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    }

    /**
     * Get color for severity level
     * @param {string} severity - Severity level (high, medium, low)
     * @returns {string} Color code
     */
    getSeverityColor(severity) {
        const colors = {
            high: '#dc3545',      // red
            critical: '#dc3545',  // red
            medium: '#fd7e14',    // orange
            warning: '#ffc107',   // yellow
            low: '#0dcaf0',       // blue
            healthy: '#198754',   // green
            normal: '#6c757d'     // gray
        };

        return colors[severity?.toLowerCase()] || colors.normal;
    }

    /**
     * Get CSS class for status
     * @param {string} status - Status string
     * @returns {string} CSS class name
     */
    getStatusClass(status) {
        const statusMap = {
            healthy: 'status-healthy',
            warning: 'status-warning',
            critical: 'status-critical',
            processed: 'status-healthy',
            pending: 'status-warning',
            failed: 'status-critical',
            unknown: 'status-unknown'
        };

        return statusMap[status?.toLowerCase()] || 'status-unknown';
    }

    /**
     * Escape HTML to prevent XSS
     * @param {string} text - Text to escape
     * @returns {string} Escaped text
     */
    escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    /**
     * Update a specific system card
     * @param {string} systemId - System ID
     * @param {Object} data - Updated system data
     */
    updateSystemCard(systemId, data) {
        const card = document.querySelector(`.system-card[data-system-id="${systemId}"]`);
        if (!card) return;

        // Update file count
        const fileCountEl = card.querySelector('.stat-value');
        if (fileCountEl && data.fileCount !== undefined) {
            fileCountEl.textContent = this.formatNumber(data.fileCount);
        }

        // Update SLA score
        const slaScoreEl = card.querySelectorAll('.stat-value')[1];
        if (slaScoreEl && data.slaScore !== undefined) {
            slaScoreEl.textContent = data.slaScore.toFixed(1);
        }

        // Update status
        const statusBadge = card.querySelector('.status-badge');
        if (statusBadge && data.status) {
            statusBadge.textContent = data.status;
            statusBadge.className = `status-badge ${this.getStatusClass(data.status)}`;
        }

        // Update warning indicator
        const hasViolations = data.hasViolations || data.slaScore < 80;
        if (hasViolations && !card.querySelector('.warning-indicator')) {
            const header = card.querySelector('.system-header');
            header.innerHTML += '<span class="warning-indicator">⚠️</span>';
            card.classList.add('has-warning');
        } else if (!hasViolations) {
            const warningIndicator = card.querySelector('.warning-indicator');
            if (warningIndicator) warningIndicator.remove();
            card.classList.remove('has-warning');
        }
    }
}
