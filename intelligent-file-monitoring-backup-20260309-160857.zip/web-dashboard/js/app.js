/**
 * Main Application Module
 * Orchestrates the dashboard application lifecycle
 * 
 * Requirements: 5.1, 5.2, 5.4, 5.5, 5.6, 6.2, 8.6
 */

import { APIClient } from './api-client.js?v=5';
import { StateManager } from './state-manager.js?v=2';
import { UIManager } from './ui-manager.js?v=2';
import { ChartRenderer } from './chart-renderer.js?v=2';
import { AIInsightsManager } from './ai-insights-manager.js?v=3';
import { ThemeManager } from './theme-manager.js?v=1';
import { DatePresetsManager } from './date-presets.js?v=1';
import { ChatWidget } from './chat-widget.js?v=1';
import { ChatManager } from './chat-manager.js?v=3';
import { MessageFormatter } from './message-formatter.js?v=1';

export class DashboardApp {
    constructor() {
        this.config = null;
        this.apiClient = null;
        this.stateManager = null;
        this.uiManager = null;
        this.chartRenderer = null;
        this.aiInsightsManager = null;
        this.themeManager = null;
        this.datePresetsManager = null;
        this.chatWidget = null;
        this.chatManager = null;
        this.messageFormatter = null;
        this.autoRefreshInterval = null;
        this.isUserInteracting = false;
        console.log('DashboardApp created');
    }

    /**
     * Initialize the application
     * Requirements: 5.1, 5.2, 6.2
     */
    async initialize() {
        try {
            console.log('Initializing Dashboard Application...');

            // Load configuration
            await this.loadConfig();

            // Create component instances
            this.apiClient = new APIClient(this.config.apiBaseURL);
            this.stateManager = new StateManager();
            this.uiManager = new UIManager(this.stateManager, this.apiClient);
            this.chartRenderer = new ChartRenderer();
            this.aiInsightsManager = new AIInsightsManager(this.apiClient, this.uiManager);
            this.themeManager = new ThemeManager();
            this.datePresetsManager = new DatePresetsManager(this.stateManager);
            
            // Create chat components
            this.chatManager = new ChatManager(this.apiClient);
            this.messageFormatter = new MessageFormatter();
            this.chatWidget = new ChatWidget(this.chatManager, this.messageFormatter);

            // Configure API client with retry policy from config
            this.apiClient.setRetryPolicy(
                this.config.retryAttempts,
                this.config.retryBackoff
            );

            // Initialize theme manager first (for visual consistency)
            this.themeManager.initialize();

            // Setup event listeners
            this.setupEventListeners();

            // Initialize UI
            this.uiManager.initialize();
            
            // Initialize date presets
            this.datePresetsManager.initialize();
            
            // Initialize chat widget
            this.chatWidget.initialize();

            // Load state from URL (for bookmarked views)
            this.stateManager.loadStateFromURL();

            // Load initial data
            await this.refreshAllData();

            // Start auto-refresh
            this.startAutoRefresh();

            console.log('Dashboard Application initialized successfully');
        } catch (error) {
            this.handleError(error);
            throw error;
        }
    }

    /**
     * Load configuration from config.json
     * Requirements: 10.2, 10.5
     */
    async loadConfig() {
        try {
            const response = await fetch('./config/config.json');
            if (!response.ok) {
                throw new Error('Failed to load configuration');
            }
            this.config = await response.json();
            console.log('Configuration loaded:', this.config);
        } catch (error) {
            console.warn('Failed to load config.json, using defaults:', error);
            // Fallback to default configuration (Requirement 10.5)
            this.config = {
                apiBaseURL: 'http://localhost:8000',
                refreshInterval: 30000,
                cacheTimeout: 30000,
                retryAttempts: 3,
                retryBackoff: 100,
                chartMaxDataPoints: 100,
                paginationPageSize: 50
            };
        }
    }

    /**
     * Setup event listeners for state changes and user interactions
     * Requirements: 5.5, 6.2
     */
    setupEventListeners() {
        // System selection change
        this.stateManager.subscribe('systemChanged', (data) => {
            this.handleSystemSelection(data.systemId);
            // Update chat examples based on selected system
            if (this.chatWidget) {
                this.chatWidget.updateExamples(data.systemId);
            }
        });

        // Filter changes
        this.stateManager.subscribe('filtersChanged', () => {
            this.handleFilterChange();
        });

        this.stateManager.subscribe('dateRangeChanged', () => {
            this.handleDateRangeChange();
        });

        // Manual refresh
        this.stateManager.subscribe('manualRefresh', () => {
            this.handleManualRefresh();
        });

        // Page change (pagination)
        this.stateManager.subscribe('pageChange', async (data) => {
            await this.refreshSelectedSystemData();
        });

        // AI panel toggle functionality
        document.addEventListener('click', (e) => {
            const panelHeader = e.target.closest('.ai-panel-header');
            if (panelHeader) {
                const panel = panelHeader.closest('.ai-panel');
                if (panel) {
                    panel.classList.toggle('collapsed');
                }
            }
        });

        // Track user interaction to pause auto-refresh (Requirement 5.5)
        document.addEventListener('mousedown', () => {
            this.isUserInteracting = true;
        });

        document.addEventListener('mouseup', () => {
            setTimeout(() => {
                this.isUserInteracting = false;
            }, 1000); // Resume auto-refresh 1 second after interaction ends
        });

        document.addEventListener('keydown', () => {
            this.isUserInteracting = true;
        });

        document.addEventListener('keyup', () => {
            setTimeout(() => {
                this.isUserInteracting = false;
            }, 1000);
        });

        // Network connectivity monitoring (Requirement 8.4)
        window.addEventListener('online', () => {
            console.log('Network connection restored');
            this.uiManager.showNotification('Connection restored', 'success');
            this.refreshAllData();
        });

        window.addEventListener('offline', () => {
            console.log('Network connection lost');
            this.uiManager.showNotification('No internet connection', 'error');
        });
    }

    /**
     * Refresh all dashboard data
     * Requirements: 5.2
     */
    async refreshAllData() {
        try {
            console.log('Refreshing all data...');

            // Show loading state
            this.uiManager.renderLoadingState('system-overview');

            // Refresh system overview
            await this.refreshSystemOverview();

            // If a system is selected, refresh its data
            const selectedSystem = this.stateManager.getSelectedSystem();
            if (selectedSystem) {
                await this.refreshSelectedSystemData();
            }

            // Update last refresh time (Requirement 5.6)
            this.stateManager.updateLastRefreshTime();
            this.uiManager.updateLastRefreshTime(this.stateManager.getLastRefreshTime());

            console.log('All data refreshed successfully');
        } catch (error) {
            this.handleError(error);
        }
    }

    /**
     * Refresh system overview data
     * Requirements: 1.1, 1.2, 1.3, 1.4
     */
    async refreshSystemOverview() {
        try {
            console.log('Refreshing system overview...');

            // Clear cache to ensure fresh data
            this.apiClient.clearCache();

            // Get date range from state
            const dateRange = this.stateManager.getDateRange();
            
            // Always fetch today's summary for "File Count (Today)"
            const todaySummary = await this.apiClient.getSystemsSummary({});
            console.log('Fetched today summary:', todaySummary.length, 'systems');
            
            // If date range is selected, also fetch range summary for "Total File Count"
            let rangeSummary = null;
            const dateRangeParams = {};
            if (dateRange.startDate && dateRange.endDate) {
                dateRangeParams.start_date = dateRange.startDate.toISOString().split('T')[0];
                dateRangeParams.end_date = dateRange.endDate.toISOString().split('T')[0];
                console.log('Fetching system summary with date range:', dateRangeParams);
                rangeSummary = await this.apiClient.getSystemsSummary(dateRangeParams);
                console.log('Fetched range summary:', rangeSummary.length, 'systems');
            }

            // Fetch SLA scores for all systems (with date range if available)
            const slaPromises = todaySummary.map(system => 
                this.apiClient.getAverageSLAScore(
                    system.source_system_id, 
                    30, 
                    dateRangeParams
                ).catch(err => {
                    console.warn(`Failed to fetch SLA for ${system.source_system_id}:`, err);
                    return null;
                })
            );
            const slaScores = await Promise.all(slaPromises);

            // Merge the summaries - combine today's count, range count, and SLA score
            const mergedSummary = todaySummary.map((todaySystem, index) => {
                const systemId = todaySystem.source_system_id;
                const rangeSystem = rangeSummary ? rangeSummary.find(s => s.source_system_id === systemId) : null;
                const slaData = slaScores[index];
                
                return {
                    ...todaySystem,
                    file_count_today: todaySystem.file_count,
                    file_count_range: rangeSystem ? rangeSystem.file_count : null,
                    sla_score: slaData ? slaData.average_score : null
                };
            });

            // Render system overview cards with both counts and SLA
            this.uiManager.renderSystemOverview(mergedSummary);

            console.log(`System overview refreshed: ${mergedSummary.length} systems`);
        } catch (error) {
            console.error('Failed to refresh system overview:', error);
            this.handleError(error);
        }
    }

    /**
     * Refresh data for the selected system
     * Requirements: 2.1, 3.1, 4.1, 6.2
     */
    async refreshSelectedSystemData() {
        const selectedSystem = this.stateManager.getSelectedSystem();
        if (!selectedSystem) {
            console.log('No system selected, skipping data refresh');
            return;
        }

        try {
            console.log(`Refreshing data for system: ${selectedSystem}`);

            // Get current filters
            const dateRange = this.stateManager.getDateRange();
            const filters = this.stateManager.getFilters();

            console.log('Date range from state:', dateRange);
            console.log('Filters from state:', filters);

            // Build filter object for API calls
            const apiFilters = {
                source_system_id: selectedSystem,
                start_date: dateRange.startDate ? dateRange.startDate.toISOString().split('T')[0] : null,
                end_date: dateRange.endDate ? dateRange.endDate.toISOString().split('T')[0] : null,
                ...filters
            };

            console.log('API filters being sent:', apiFilters);

            // Fetch file arrivals
            this.uiManager.renderLoadingState('file-arrivals');
            const fileArrivals = await this.apiClient.getFileArrivals(apiFilters);
            console.log(`Received ${fileArrivals.length} file arrivals from API`);
            this.uiManager.renderFileArrivals(fileArrivals);

            // Fetch SLA data
            this.uiManager.renderLoadingState('sla-metrics');
            const [slaScores, slaViolations] = await Promise.all([
                this.apiClient.getAverageSLAScore(selectedSystem),
                this.apiClient.getSLAViolations(apiFilters)
            ]);
            this.uiManager.renderSLAMetrics(slaScores, slaViolations);

            // Fetch and render charts
            await this.renderCharts(selectedSystem);

            console.log(`Data refreshed for system: ${selectedSystem}`);
        } catch (error) {
            console.error('Failed to refresh selected system data:', error);
            this.handleError(error);
        }
    }

    /**
     * Render charts for the selected system
     * Requirements: 4.1, 4.2, 4.3, 4.4
     */
    async renderCharts(systemId) {
        try {
            const dateRange = this.stateManager.getDateRange();
            let days = 30; // Default to 30 days
            
            if (dateRange.startDate && dateRange.endDate) {
                days = Math.ceil((dateRange.endDate - dateRange.startDate) / (1000 * 60 * 60 * 24));
                // Ensure minimum 7 days for moving average
                days = Math.max(days, 7);
            }

            console.log(`Fetching chart data for system: ${systemId}, days: ${days}`);

            // Fetch trend data with proper error handling
            let dailyTrends = [];
            let movingAverage = [];
            let hourlyPatterns = [];

            try {
                [dailyTrends, movingAverage, hourlyPatterns] = await Promise.all([
                    this.apiClient.getDailyTrends(systemId, days).catch(err => {
                        console.warn('Failed to fetch daily trends:', err);
                        return [];
                    }),
                    this.apiClient.getMovingAverage(systemId, days).catch(err => {
                        console.warn('Failed to fetch moving average:', err);
                        return [];
                    }),
                    this.apiClient.getHourlyPatterns(systemId, Math.max(days, 7)).catch(err => {
                        console.warn('Failed to fetch hourly patterns:', err);
                        return [];
                    })
                ]);
            } catch (error) {
                console.error('Error fetching chart data:', error);
            }

            console.log('API responses:', {
                dailyTrends: dailyTrends,
                movingAverage: movingAverage,
                hourlyPatterns: hourlyPatterns
            });

            // Transform API data to chart format (timestamp, value)
            // Daily trends: arrival_date -> timestamp, file_count -> value
            if (dailyTrends && dailyTrends.length > 0) {
                console.log('Sample daily trend point:', dailyTrends[0]);
                const transformedDaily = dailyTrends.map(point => ({
                    timestamp: point.arrival_date || point.date,
                    value: point.file_count || point.count || 0
                }));
                
                console.log('Transformed daily data:', transformedDaily.slice(0, 3));
                
                this.chartRenderer.createDailyTrendChart('daily-trend-chart', {
                    sourceSystemId: systemId,
                    dataPoints: transformedDaily,
                    aggregationType: 'daily'
                });
            } else {
                console.warn('No daily trends data available');
                // Show "no data" message in chart area
                const canvas = document.getElementById('daily-trend-chart');
                if (canvas) {
                    const parent = canvas.parentElement;
                    if (parent) {
                        const noData = parent.querySelector('.no-data') || document.createElement('p');
                        noData.className = 'no-data';
                        noData.textContent = 'No daily trend data available';
                        parent.appendChild(noData);
                    }
                }
            }

            // Moving average: date -> timestamp, moving_avg_7day -> value
            if (movingAverage && movingAverage.length > 0) {
                console.log('Sample moving average point:', movingAverage[0]);
                const transformedMA = movingAverage.map(point => ({
                    timestamp: point.date || point.arrival_date,
                    value: point.moving_avg_7day || point.file_count || 0
                }));
                
                console.log('Transformed moving average data:', transformedMA.slice(0, 3));
                
                this.chartRenderer.createMovingAverageChart('moving-average-chart', {
                    sourceSystemId: systemId,
                    dataPoints: transformedMA,
                    aggregationType: 'moving_average'
                });
            } else {
                console.warn('No moving average data available');
                const canvas = document.getElementById('moving-average-chart');
                if (canvas) {
                    const parent = canvas.parentElement;
                    if (parent) {
                        const noData = parent.querySelector('.no-data') || document.createElement('p');
                        noData.className = 'no-data';
                        noData.textContent = 'No moving average data available';
                        parent.appendChild(noData);
                    }
                }
            }

            // Hourly patterns: create timestamp from hour_of_day, file_count -> value
            if (hourlyPatterns && hourlyPatterns.length > 0) {
                console.log('Sample hourly pattern point:', hourlyPatterns[0]);
                const transformedHourly = hourlyPatterns.map(point => {
                    // Create a timestamp for the hour (using today's date)
                    const today = new Date();
                    today.setHours(point.hour_of_day || point.hour || 0, 0, 0, 0);
                    
                    return {
                        timestamp: today.toISOString(),
                        value: point.file_count || point.avg_count || 0
                    };
                });
                
                console.log('Transformed hourly data:', transformedHourly.slice(0, 3));
                
                this.chartRenderer.createHourlyPatternChart('hourly-pattern-chart', {
                    sourceSystemId: systemId,
                    dataPoints: transformedHourly,
                    aggregationType: 'hourly'
                });
            } else {
                console.warn('No hourly patterns data available');
                const canvas = document.getElementById('hourly-pattern-chart');
                if (canvas) {
                    const parent = canvas.parentElement;
                    if (parent) {
                        const noData = parent.querySelector('.no-data') || document.createElement('p');
                        noData.className = 'no-data';
                        noData.textContent = 'No hourly pattern data available';
                        parent.appendChild(noData);
                    }
                }
            }

            console.log('Charts rendered successfully');
        } catch (error) {
            console.error('Failed to render charts:', error);
            console.error('Error stack:', error.stack);
            // Don't throw - charts are non-critical
        }
    }

    /**
     * Start auto-refresh with 30-second interval
     * Requirements: 5.1, 5.5
     */
    startAutoRefresh() {
        // Clear any existing interval
        this.stopAutoRefresh();

        console.log(`Starting auto-refresh with ${this.config.refreshInterval}ms interval`);

        this.autoRefreshInterval = setInterval(() => {
            // Pause auto-refresh during user interaction (Requirement 5.5)
            if (this.isUserInteracting) {
                console.log('Auto-refresh paused due to user interaction');
                return;
            }

            console.log('Auto-refresh triggered');
            this.refreshAllData();
        }, this.config.refreshInterval);

        this.stateManager.setAutoRefreshEnabled(true);
    }

    /**
     * Stop auto-refresh
     * Requirements: 5.1
     */
    stopAutoRefresh() {
        if (this.autoRefreshInterval) {
            clearInterval(this.autoRefreshInterval);
            this.autoRefreshInterval = null;
            this.stateManager.setAutoRefreshEnabled(false);
            console.log('Auto-refresh stopped');
        }
    }

    /**
     * Handle system selection event
     * Requirements: 6.2
     */
    async handleSystemSelection(systemId) {
        console.log(`System selected: ${systemId}`);

        try {
            // Show/hide details section based on selection
            const detailsSection = document.getElementById('details-section');
            if (detailsSection) {
                if (systemId) {
                    detailsSection.classList.remove('hidden');
                } else {
                    detailsSection.classList.add('hidden');
                }
            }

            // Show/hide AI insights section based on selection
            const aiInsightsSection = document.getElementById('ai-insights-section');
            if (aiInsightsSection) {
                if (systemId) {
                    aiInsightsSection.classList.remove('hidden');
                } else {
                    aiInsightsSection.classList.add('hidden');
                    this.aiInsightsManager.clear();
                }
            }

            // Clear previous charts
            this.chartRenderer.destroyAllCharts();

            // Refresh system overview to show filtered view
            await this.refreshSystemOverview();

            // Refresh data for the selected system
            if (systemId) {
                await this.refreshSelectedSystemData();
                
                // Load AI insights asynchronously (non-blocking)
                this.loadAIInsights(systemId);
            }

            // Update URL to reflect selection (handled by StateManager)
        } catch (error) {
            this.handleError(error);
        }
    }

    /**
     * Handle filter change event
     * Requirements: 6.2, 6.4
     */
    async handleFilterChange() {
        console.log('Filters changed');

        try {
            // Refresh data with new filters
            await this.refreshSelectedSystemData();
        } catch (error) {
            this.handleError(error);
        }
    }

    /**
     * Handle date range change event
     * Refreshes both system data and AI insights
     */
    async handleDateRangeChange() {
        console.log('Date range changed');

        try {
            const selectedSystem = this.stateManager.getSelectedSystem();
            
            // Refresh system overview with new date range
            await this.refreshSystemOverview();
            
            // Refresh selected system data if any
            if (selectedSystem) {
                await this.refreshSelectedSystemData();
                
                // Reload AI insights with new date range
                this.loadAIInsights(selectedSystem);
            }
        } catch (error) {
            this.handleError(error);
        }
    }

    /**
     * Load AI insights for the selected system
     * Non-blocking operation that runs in the background
     * @param {string} systemId - Source system identifier
     */
    async loadAIInsights(systemId) {
        try {
            const dateRange = this.stateManager.getDateRange();
            
            // If no date range is set, use last 7 days as default
            let startDate, endDate;
            
            if (dateRange.startDate && dateRange.endDate) {
                // Convert Date objects to YYYY-MM-DD strings
                startDate = dateRange.startDate.toISOString().split('T')[0];
                endDate = dateRange.endDate.toISOString().split('T')[0];
            } else {
                // Default to last 7 days
                const today = new Date();
                const sevenDaysAgo = new Date(today);
                sevenDaysAgo.setDate(today.getDate() - 7);
                
                startDate = sevenDaysAgo.toISOString().split('T')[0];
                endDate = today.toISOString().split('T')[0];
                
                console.log(`No date range selected, using default: ${startDate} to ${endDate}`);
            }
            
            // Load AI insights asynchronously without blocking the UI
            await this.aiInsightsManager.loadInsights(
                systemId,
                startDate,
                endDate
            );
            
            console.log('AI insights loaded successfully');
        } catch (error) {
            console.error('Failed to load AI insights:', error);
            // Don't throw - AI insights are supplementary and shouldn't break the app
        }
    }

    /**
     * Handle date range change event
     * Requirements: 6.2, 6.4
     */
    async handleDateRangeChange() {
        console.log('Date range changed - refreshing overview and selected system data');

        try {
            // Always refresh system overview when date range changes
            await this.refreshSystemOverview();
            
            // Also refresh selected system data if a system is selected
            const selectedSystem = this.stateManager.getSelectedSystem();
            if (selectedSystem) {
                await this.refreshSelectedSystemData();
            }
        } catch (error) {
            this.handleError(error);
        }
    }

    /**
     * Handle manual refresh button click
     * Requirements: 5.4
     */
    async handleManualRefresh() {
        console.log('Manual refresh triggered');

        try {
            // Disable refresh button temporarily
            const refreshBtn = document.getElementById('manual-refresh');
            if (refreshBtn) {
                refreshBtn.disabled = true;
            }

            // Refresh all data
            await this.refreshAllData();

            // Show success notification
            this.uiManager.showNotification('Data refreshed successfully', 'success');

            // Re-enable refresh button
            if (refreshBtn) {
                refreshBtn.disabled = false;
            }
        } catch (error) {
            this.handleError(error);

            // Re-enable refresh button on error
            const refreshBtn = document.getElementById('manual-refresh');
            if (refreshBtn) {
                refreshBtn.disabled = false;
            }
        }
    }

    /**
     * Handle errors with logging and user feedback
     * Requirements: 8.1, 8.6
     */
    handleError(error) {
        // Log error to console (Requirement 8.6)
        console.error('Dashboard error:', error);

        // Log stack trace if available
        if (error.stack) {
            console.error('Stack trace:', error.stack);
        }

        // Display user-friendly error message (Requirement 8.1)
        this.uiManager.renderErrorMessage(error);

        // Show notification
        const errorMessage = error instanceof Error ? error.message : String(error);
        this.uiManager.showNotification(errorMessage, 'error');
    }

    /**
     * Start the application
     */
    start() {
        console.log('Starting Dashboard Application...');
        this.initialize().catch(error => {
            console.error('Failed to start application:', error);
        });
    }

    /**
     * Stop the application and clean up resources
     */
    stop() {
        console.log('Stopping Dashboard Application...');
        this.stopAutoRefresh();
        this.chartRenderer.destroyAllCharts();
        this.apiClient.clearCache();
        this.stateManager.clearCache();
    }
}

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM ready - Initializing Dashboard Application');
    
    const app = new DashboardApp();
    app.start();

    // Make app globally accessible for debugging
    window.dashboardApp = app;
});
