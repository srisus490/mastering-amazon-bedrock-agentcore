"""SLA endpoints"""

from datetime import date, timedelta
from typing import List, Optional

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

from src.sla.calculator import ScoreCalculator
from src.sla.tracker import ViolationTracker

router = APIRouter()


class SLAScoreResponse(BaseModel):
    date: str
    score: float


class ViolationResponse(BaseModel):
    id: int
    source_system_id: str
    violation_date: date
    violation_type: str
    expected_value: Optional[str]
    actual_value: Optional[str]
    severity: str
    
    class Config:
        from_attributes = True


@router.get("/scores/{source_system_id}", response_model=List[SLAScoreResponse])
async def get_sla_scores(
    source_system_id: str,
    days: int = Query(30, ge=1, le=90),
):
    """Get SLA scores for a source system"""
    calculator = ScoreCalculator()
    
    end_date = date.today()
    start_date = end_date - timedelta(days=days)
    
    try:
        scores = calculator.calculate_score_range(source_system_id, start_date, end_date)
        return scores
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/average-score/{source_system_id}")
async def get_average_score(
    source_system_id: str,
    days: int = Query(30, ge=1, le=90),
    start_date: Optional[date] = Query(None),
    end_date: Optional[date] = Query(None),
):
    """Get average SLA score for a source system"""
    calculator = ScoreCalculator()
    
    # Use explicit dates if provided, otherwise use days parameter
    if start_date and end_date:
        calc_start_date = start_date
        calc_end_date = end_date
    else:
        calc_end_date = date.today()
        calc_start_date = calc_end_date - timedelta(days=days)
    
    try:
        avg_score = calculator.get_average_score(source_system_id, calc_start_date, calc_end_date)
        return {
            "source_system_id": source_system_id,
            "start_date": calc_start_date.isoformat(),
            "end_date": calc_end_date.isoformat(),
            "average_score": avg_score,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/violations", response_model=List[ViolationResponse])
async def get_violations(
    source_system_id: Optional[str] = Query(None),
    start_date: Optional[date] = Query(None),
    end_date: Optional[date] = Query(None),
    severity: Optional[str] = Query(None),
    limit: int = Query(100, le=1000),
):
    """Get SLA violations with optional filters"""
    tracker = ViolationTracker()
    
    try:
        violations = tracker.get_violations(
            source_system_id=source_system_id,
            start_date=start_date,
            end_date=end_date,
            severity=severity,
            limit=limit,
        )
        return violations
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/violations/by-severity/{source_system_id}")
async def get_violations_by_severity(
    source_system_id: str,
    days: int = Query(30, ge=1, le=90),
):
    """Get violation counts grouped by severity"""
    tracker = ViolationTracker()
    
    end_date = date.today()
    start_date = end_date - timedelta(days=days)
    
    try:
        severity_counts = tracker.get_violations_by_severity(
            source_system_id=source_system_id,
            start_date=start_date,
            end_date=end_date,
        )
        return {
            "source_system_id": source_system_id,
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
            "severity_counts": severity_counts,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
