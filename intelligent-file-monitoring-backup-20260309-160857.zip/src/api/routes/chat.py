"""Chat API endpoints for conversational AI assistant."""

import os
from datetime import datetime
from typing import List

from fastapi import APIRouter, HTTPException
from sqlalchemy import text

from src.ai.agent_action_handler import get_action_handler
from src.ai.agentcore_client import get_agentcore_client
from src.ai.agentcore_runtime_client import AgentCoreRuntimeClient
from src.ai.bedrock_agent_client import get_agent_client
from src.ai.chat_cache_manager import get_chat_cache
from src.ai.cost_monitor import get_cost_monitor
from src.ai.intelligent_query_parser import IntelligentQueryParser
from src.ai.knowledge_base_client import get_kb_client
from src.ai.models import ChatRequest, ChatResponse, TokenUsage
from src.ai.query_processor import QueryProcessor, QueryType
from src.ai.response_generator import ResponseGenerator
from src.ai.sql_query_generator import SQLQueryGenerator
from src.ai.bedrock_client import (
    BedrockAuthError,
    BedrockRateLimitError,
    BedrockTimeoutError,
    BedrockUnavailableError,
    BedrockError
)
from src.core.logging import get_logger
from src.database.connection import get_db_session
from src.database.models import SourceSystemModel

logger = get_logger(__name__)

router = APIRouter()

# Initialize components
_query_processor = None
_intelligent_parser = None
_sql_generator = None
_response_generator = None
_cache_manager = None
_runtime_client = None


def _get_runtime_client() -> AgentCoreRuntimeClient:
    """Get or create runtime client instance."""
    global _runtime_client
    if _runtime_client is None:
        # Read agent ARN from environment variable
        agent_arn = os.environ.get("AGENTCORE_RUNTIME_AGENT_ARN")
        if not agent_arn:
            raise ValueError("AGENTCORE_RUNTIME_AGENT_ARN environment variable not set")
        
        # Initialize runtime client
        _runtime_client = AgentCoreRuntimeClient(agent_arn=agent_arn)
        logger.info(f"Initialized runtime client with agent ARN: {agent_arn}")
    
    return _runtime_client


def _get_intelligent_parser() -> IntelligentQueryParser:
    """Get or create intelligent query parser instance."""
    global _intelligent_parser
    if _intelligent_parser is None:
        # Get available systems from database
        with get_db_session() as session:
            systems = session.query(SourceSystemModel.id).all()
            system_ids = [s.id for s in systems]
        _intelligent_parser = IntelligentQueryParser(available_systems=system_ids)
    return _intelligent_parser


def _get_query_processor() -> QueryProcessor:
    """Get or create query processor instance."""
    global _query_processor
    if _query_processor is None:
        # Get available systems from database
        with get_db_session() as session:
            systems = session.query(SourceSystemModel.id).all()
            system_ids = [s.id for s in systems]
        _query_processor = QueryProcessor(available_systems=system_ids)
    return _query_processor


def _get_sql_generator() -> SQLQueryGenerator:
    """Get or create SQL generator instance."""
    global _sql_generator
    if _sql_generator is None:
        _sql_generator = SQLQueryGenerator()
    return _sql_generator


def _get_response_generator() -> ResponseGenerator:
    """Get or create response generator instance."""
    global _response_generator
    if _response_generator is None:
        _response_generator = ResponseGenerator()
    return _response_generator


def _get_cache_manager():
    """Get cache manager instance."""
    global _cache_manager
    if _cache_manager is None:
        _cache_manager = get_chat_cache()
    return _cache_manager


@router.post("/query", response_model=ChatResponse)
async def chat_query(request: ChatRequest) -> ChatResponse:
    """
    Process a natural language query and return an AI-generated response.
    
    This endpoint:
    1. Checks cache for recent identical queries
    2. Parses the natural language query
    3. Generates and executes SQL queries
    4. Uses Bedrock to generate natural language responses
    5. Caches the response for future use
    """
    try:
        # Get components
        intelligent_parser = _get_intelligent_parser()
        sql_generator = _get_sql_generator()
        response_generator = _get_response_generator()
        cache_manager = _get_cache_manager()
        cost_monitor = get_cost_monitor()
        
        # Check circuit breaker
        if cost_monitor.isCircuitBreakerActive():
            logger.warning("Circuit breaker active - rejecting query")
            raise HTTPException(
                status_code=503,
                detail="Chat service temporarily disabled due to cost limits. Please try again later."
            )
        
        # Check cache first
        query_hash = cache_manager.generateQueryHash(request.query, request.context)
        cached_response = cache_manager.getCachedResponse(query_hash)
        
        if cached_response:
            logger.info("Returning cached response")
            return ChatResponse(**cached_response, cached=True)
        
        # Parse the query using intelligent parser
        context_dicts = [msg.dict() for msg in request.context] if request.context else []
        parsed = intelligent_parser.parseQuery(request.query, context_dicts)
        
        logger.info(
            f"Parsed query intent",
            query_type=parsed['intent'],
            system_ids=parsed['systems'],
            confidence=parsed['confidence'],
            is_greeting=parsed['is_greeting']
        )
        
        # Handle greetings
        if parsed['is_greeting']:
            greeting = parsed.get('greeting_response') or "Hello! How can I help you with the file monitoring dashboard today?"
            return ChatResponse(
                response=greeting,
                data=None,
                suggestions=[
                    "Show me system health",
                    "What violations occurred recently?",
                    "How is PROD_BACKUP doing?"
                ],
                cached=False,
                tokens_used=TokenUsage(input=50, output=20, cached=0)
            )
        
        # Handle out-of-scope queries
        if parsed.get('is_out_of_scope'):
            out_of_scope_msg = parsed.get('out_of_scope_response') or \
                "I'm a file monitoring assistant. I can help you with system health, SLA violations, trends, and comparisons. I can't answer general questions like that."
            return ChatResponse(
                response=out_of_scope_msg,
                data=None,
                suggestions=[
                    "Show me system health",
                    "What violations occurred recently?",
                    "Compare PROD_SALES and PROD_INVENTORY"
                ],
                cached=False,
                tokens_used=TokenUsage(input=50, output=30, cached=0)
            )
        
        # Handle low confidence
        if parsed['confidence'] < 0.5:
            return ChatResponse(
                response="I'm not sure I understand. Could you rephrase your question?",
                data=None,
                suggestions=[
                    "How is PROD_SALES doing?",
                    "Show me violations from last week",
                    "Compare PROD_SALES and PROD_INVENTORY"
                ],
                cached=False,
                tokens_used=TokenUsage(input=0, output=0, cached=0)
            )
        
        intent = parsed['intent']
        system_ids = parsed['systems']
        date_range = parsed['date_range']
        
        # Check if query would be expensive
        is_expensive, suggestion = sql_generator.isExpensiveQuery(
            date_range,
            len(system_ids)
        )
        if is_expensive:
            return ChatResponse(
                response=f"This query might take a while. {suggestion}",
                data=None,
                suggestions=["Try a shorter date range", "Focus on one system"],
                cached=False,
                tokens_used=TokenUsage(input=0, output=0, cached=0)
            )
        
        # Generate and execute SQL query
        query_result = None
        
        if intent == "SYSTEM_HEALTH":
            if not system_ids:
                return ChatResponse(
                    response="Which system would you like to check?",
                    data=None,
                    suggestions=["PROD_SALES", "PROD_ANALYTICS", "PROD_INVENTORY"],
                    cached=False,
                    tokens_used=TokenUsage(input=0, output=0, cached=0)
                )
            
            sql, params = sql_generator.generateHealthQuery(
                system_ids[0],
                date_range
            )
            query_result = _execute_query(sql, params)
        
        elif intent == "SLA_VIOLATIONS":
            filters = {
                'system_ids': system_ids,
                'date_range': date_range
            }
            sql, params = sql_generator.generateViolationsQuery(filters)
            query_result = _execute_query(sql, params)
        
        elif intent == "FILE_TRENDS":
            if not system_ids:
                return ChatResponse(
                    response="Which system's trends would you like to see?",
                    data=None,
                    suggestions=["Show trends for PROD_SALES"],
                    cached=False,
                    tokens_used=TokenUsage(input=0, output=0, cached=0)
                )
            
            sql, params = sql_generator.generateTrendsQuery(
                system_ids[0],
                date_range or _get_default_date_range()
            )
            query_result = _execute_query(sql, params)
        
        elif intent == "SYSTEM_COMPARISON":
            if len(system_ids) < 2:
                return ChatResponse(
                    response="Please specify at least two systems to compare.",
                    data=None,
                    suggestions=["Compare PROD_SALES and PROD_ANALYTICS"],
                    cached=False,
                    tokens_used=TokenUsage(input=0, output=0, cached=0)
                )
            
            sql, params = sql_generator.generateComparisonQuery(
                system_ids,
                date_range
            )
            query_result = _execute_query(sql, params)
        
        elif intent == "GENERAL_INFO":
            # For general info, just list available systems
            with get_db_session() as session:
                systems = session.query(SourceSystemModel).filter_by(is_active=True).all()
                query_result = [
                    {'id': s.id, 'name': s.name, 'is_active': s.is_active}
                    for s in systems
                ]
        
        # Retrieve relevant context from Knowledge Base
        kb_client = get_kb_client()
        kb_context = None
        
        if kb_client.is_available():
            try:
                logger.info("Retrieving Knowledge Base context")
                retrieved_docs = kb_client.retrieve(
                    query=request.query,
                    max_results=5,
                    similarity_threshold=0.7
                )
                
                if retrieved_docs:
                    kb_context = kb_client.format_context(retrieved_docs)
                    logger.info(f"Retrieved {len(retrieved_docs)} KB documents")
                else:
                    logger.info("No relevant KB documents found")
            except Exception as e:
                logger.warning(f"KB retrieval failed, continuing without KB context: {e}")
        
        # Generate natural language response using Bedrock with KB context
        response_data = response_generator.generateResponse(
            query_result,
            request.query,
            context_dicts,
            kb_context=kb_context
        )
        
        # Generate suggestions
        suggestions = response_generator.generateSuggestions(
            intent.query_type.value,
            intent.system_ids
        )
        
        # Build response
        chat_response = ChatResponse(
            response=response_data['response'],
            data=query_result if query_result else None,
            suggestions=suggestions,
            cached=False,
            tokens_used=TokenUsage(**response_data['tokens_used'])
        )
        
        # Record token usage for cost monitoring
        cost_info = cost_monitor.recordTokenUsage(
            input_tokens=response_data['tokens_used']['input'],
            output_tokens=response_data['tokens_used']['output'],
            cached_tokens=response_data['tokens_used']['cached']
        )
        
        # Log any cost alerts
        if cost_info['alerts']:
            for alert in cost_info['alerts']:
                logger.warning(f"Cost alert: {alert}")
        
        # Cache the response
        cache_manager.setCachedResponse(
            query_hash,
            chat_response.dict(exclude={'cached'}),
            ttl=300  # 5 minutes
        )
        
        return chat_response
    
    except BedrockAuthError as e:
        logger.error(f"Bedrock authentication error: {e}")
        raise HTTPException(
            status_code=401,
            detail="AI service authentication failed. Please check credentials."
        )
    
    except BedrockRateLimitError as e:
        logger.error(f"Bedrock rate limit error: {e}")
        raise HTTPException(
            status_code=429,
            detail="AI service rate limit exceeded. Please try again in a moment."
        )
    
    except BedrockTimeoutError as e:
        logger.error(f"Bedrock timeout error: {e}")
        raise HTTPException(
            status_code=504,
            detail="AI service request timed out. Please try again."
        )
    
    except BedrockUnavailableError as e:
        logger.error(f"Bedrock unavailable error: {e}")
        raise HTTPException(
            status_code=503,
            detail="AI service is temporarily unavailable. Please try again later."
        )
    
    except BedrockError as e:
        logger.error(f"Bedrock error: {e}")
        raise HTTPException(
            status_code=500,
            detail="AI service error. Please try again."
        )
    
    except Exception as e:
        logger.error(f"Error processing chat query: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="An error occurred processing your query.")


def _execute_query(sql: str, params: dict) -> List[dict]:
    """Execute a SQL query and return results as list of dicts."""
    sql_generator = _get_sql_generator()
    
    # Validate query
    if not sql_generator.validateQuery(sql):
        raise ValueError("Invalid SQL query")
    
    with get_db_session() as session:
        result = session.execute(text(sql), params)
        rows = result.fetchall()
        
        # Convert to list of dicts
        if rows:
            columns = result.keys()
            return [dict(zip(columns, row)) for row in rows]
        return []


def _get_default_date_range():
    """Get default date range (last 7 days)."""
    from datetime import timedelta
    end_date = datetime.now()
    start_date = end_date - timedelta(days=7)
    return (start_date, end_date)


@router.post("/clear")
async def clear_chat():
    """
    Clear conversation cache.
    
    Clears all cached responses to free memory and force fresh queries.
    """
    try:
        cache_manager = _get_cache_manager()
        cache_manager.clearCache()
        
        logger.info("Chat cache cleared")
        
        return {
            "status": "success",
            "message": "Cache cleared successfully"
        }
    except Exception as e:
        logger.error(f"Error clearing cache: {e}")
        raise HTTPException(status_code=500, detail="Failed to clear cache")


@router.get("/examples")
async def get_examples(system_id: str = None):
    """
    Get example questions for the chat interface.
    
    Returns context-aware examples based on selected system if provided.
    
    Args:
        system_id: Optional system ID for context-aware examples
    """
    try:
        # Base examples
        base_examples = [
            "How is PROD_SALES doing?",
            "Show me violations from last week",
            "What's the trend for PROD_ANALYTICS?",
            "Compare PROD_SALES and PROD_INVENTORY",
            "Why is PROD_SALES slow?"
        ]
        
        # If system_id provided, generate system-specific examples
        if system_id:
            with get_db_session() as session:
                system = session.query(SourceSystemModel).filter_by(id=system_id).first()
                if system:
                    return {
                        "examples": [
                            f"How is {system_id} doing?",
                            f"Show me violations for {system_id}",
                            f"What's the trend for {system_id}?",
                            f"Why is {system_id} having issues?",
                            "Compare all systems"
                        ]
                    }
        
        return {"examples": base_examples}
    
    except Exception as e:
        logger.error(f"Error getting examples: {e}")
        # Return base examples on error
        return {
            "examples": [
                "How is my system doing?",
                "Show me recent violations",
                "What are the trends?",
                "Compare systems"
            ]
        }


@router.get("/health")
async def chat_health():
    """
    Check chat service health.
    
    Verifies connectivity to Bedrock and database.
    """
    health_status = {
        "status": "healthy",
        "bedrock": "unknown",
        "database": "unknown",
        "cache": "unknown"
    }
    
    try:
        # Check database
        with get_db_session() as session:
            session.execute(text("SELECT 1"))
            health_status["database"] = "healthy"
    except Exception as e:
        logger.error(f"Database health check failed: {e}")
        health_status["database"] = "unhealthy"
        health_status["status"] = "degraded"
    
    try:
        # Check Bedrock credentials
        response_generator = _get_response_generator()
        if response_generator.bedrock_client.validate_credentials():
            health_status["bedrock"] = "healthy"
        else:
            health_status["bedrock"] = "unhealthy"
            health_status["status"] = "degraded"
    except Exception as e:
        logger.error(f"Bedrock health check failed: {e}")
        health_status["bedrock"] = "unhealthy"
        health_status["status"] = "degraded"
    
    try:
        # Check Knowledge Base
        kb_client = get_kb_client()
        if kb_client.is_available():
            health_status["knowledge_base"] = "healthy"
            health_status["kb_id"] = kb_client.knowledge_base_id
        else:
            health_status["knowledge_base"] = "disabled"
    except Exception as e:
        logger.error(f"Knowledge Base health check failed: {e}")
        health_status["knowledge_base"] = "unhealthy"
    
    try:
        # Check cache
        cache_manager = _get_cache_manager()
        stats = cache_manager.getCacheStats()
        health_status["cache"] = "healthy"
        health_status["cache_stats"] = stats
    except Exception as e:
        logger.error(f"Cache health check failed: {e}")
        health_status["cache"] = "unhealthy"
    
    return health_status


@router.post("/agent", response_model=ChatResponse)
async def chat_with_agent(request: ChatRequest) -> ChatResponse:
    """
    Process query using Bedrock Agent Core Runtime (intelligent agentic AI).
    
    The agent will:
    1. Understand your intent intelligently
    2. Decide which tools to use automatically
    3. Execute tools in the right order
    4. Synthesize a comprehensive answer
    5. Handle ANY question (greetings, time, dashboard queries, etc.)
    
    This is TRUE agentic AI - much smarter than basic chatbot.
    """
    try:
        # Get runtime client
        runtime_client = _get_runtime_client()
        cost_monitor = get_cost_monitor()
        
        # Check circuit breaker
        if cost_monitor.isCircuitBreakerActive():
            logger.warning("Circuit breaker active - rejecting query")
            raise HTTPException(
                status_code=503,
                detail="Chat service temporarily disabled due to cost limits."
            )
        
        # Invoke runtime agent
        logger.info(f"Invoking AgentCore Runtime for query: {request.query[:100]}")
        
        agent_response = runtime_client.invoke(
            query=request.query,
            session_id=request.session_id
        )
        
        # Check if there was an error in the response
        if agent_response.get("error"):
            # Determine appropriate HTTP status code based on error message
            error_msg = agent_response.get("response", "Unknown error")
            
            if "unavailable" in error_msg.lower():
                raise HTTPException(
                    status_code=503,
                    detail=error_msg
                )
            elif "timed out" in error_msg.lower():
                raise HTTPException(
                    status_code=504,
                    detail=error_msg
                )
            else:
                raise HTTPException(
                    status_code=500,
                    detail=error_msg
                )
        
        # Extract response data
        response_text = agent_response.get("response", "")
        tools_used = agent_response.get("tools_used", [])
        session_id = agent_response.get("session_id", request.session_id)
        
        # Estimate tokens (approximate based on text length)
        input_tokens = len(request.query.split()) * 1.3
        output_tokens = len(response_text.split()) * 1.3
        
        # Generate suggestions
        suggestions = [
            "Tell me more",
            "What about other systems?",
            "Show me trends"
        ]
        
        return ChatResponse(
            response=response_text,
            data={'tools_used': tools_used} if tools_used else None,
            suggestions=suggestions,
            cached=False,
            tokens_used=TokenUsage(
                input=int(input_tokens),
                output=int(output_tokens),
                cached=0
            )
        )
        
    except HTTPException:
        raise
    except ValueError as e:
        # Handle configuration errors (e.g., missing AGENTCORE_RUNTIME_AGENT_ARN)
        logger.error(f"Configuration error: {e}")
        raise HTTPException(
            status_code=500,
            detail="Agent configuration error. Please contact support."
        )
    except Exception as e:
        logger.error(f"Error with AgentCore Runtime: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail="An error occurred processing your request. Please try again."
        )


@router.get("/health")
async def health_check():
    """Health check endpoint."""
    kb_client = get_kb_client()
    
    health_info = {
        'status': 'healthy',
        'agent_type': 'bedrock-agentcore-runtime',
        'kb_configured': kb_client.is_available(),
        'timestamp': datetime.now().isoformat()
    }
    
    # Check if runtime agent is configured
    try:
        agent_arn = os.environ.get("AGENTCORE_RUNTIME_AGENT_ARN")
        if agent_arn:
            health_info['agent_configured'] = True
            health_info['agent_arn'] = agent_arn
        else:
            health_info['agent_configured'] = False
            health_info['status'] = 'degraded'
    except Exception as e:
        logger.error(f"Error checking agent configuration: {e}")
        health_info['agent_configured'] = False
        health_info['status'] = 'degraded'
    
    return health_info
